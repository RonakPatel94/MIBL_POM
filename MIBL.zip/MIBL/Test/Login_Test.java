package MIBL.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;
import org.testng.internal.PropertiesFile;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Login_Test {
    public WebDriver driver;



    @BeforeSuite
    @Parameters("Browser")
    public void setup(String browser) throws Exception{
        //Check if parameter passed from TestNG is 'firefox'
        if(browser.equalsIgnoreCase("firefox")){
            //create firefox instance
            System.setProperty("webdriver.gecko.driver", "resources\\geckodriver.exe");
            driver = new FirefoxDriver();
            // maximize the browser
            driver.manage().window().maximize();
        }
        //Check if parameter passed as 'chrome'
        else if(browser.equalsIgnoreCase("chrome")){
            //set path to chromedriver.exe
            System.setProperty("webdriver.chrome.driver","resources\\chromedriver.exe");
            //create chrome instance
            driver = new ChromeDriver();
            // maximize the browser
            driver.manage().window().maximize();
        }
        //Check if parameter passed as 'Edge'
        /*else if(browser.equalsIgnoreCase("Edge")){
            //set path to Edge.exe
            System.setProperty("webdriver.edge.driver",".\\MicrosoftWebDriver.exe");
            //create Edge instance
            driver = new EdgeDriver();
        }*/
        else{
            //If no browser passed throw exception
            throw new Exception("Browser is not correct");
        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }




   /* @BeforeClass
    public void SetUp() {
        // Define Chrome Driver
        System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
        driver = new ChromeDriver();

        // maximize the browser
        driver.manage().window().maximize();

        // set Implicit wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    }
*/
    @BeforeMethod
    @Parameters({"appURL"})
    public void SiteUrl(String appURL) {

        //Get URl
        driver.get(appURL);



    }
}
