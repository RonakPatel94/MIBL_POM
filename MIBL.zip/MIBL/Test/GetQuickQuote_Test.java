package MIBL.Test;

import MIBL.Pages.GetQuickQuote_Page;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.internal.PropertiesFile;

import java.io.IOException;

public class GetQuickQuote_Test extends Login_Test {

    // WebDriver driver;
    GetQuickQuote_Page obj;

  /*  @BeforeMethod
    public void beforeMethod() {

    }*/

    @Test
    public void QuickQuote() throws IOException, InterruptedException {
        obj = new GetQuickQuote_Page(driver);
        obj.readPropertiesFile();

        //obj.about();
        obj.QuickQuote();
        obj.parish();
        obj.Clarendon();
        obj.selectvehicle();
        obj.continuebtn();
        obj.manufactureyear();
        obj.vehiclemaker();
        obj.vehiclemodel();
        obj.btnprimaryuse();
        obj.btndistancetravel();
        obj.currentstatumotorcyclepayment();
        obj.typeofcover();
        obj.comprehensive();
        obj.motorcycleownedcompny();
        obj.companyname();
        obj.vehiclePurchased();
        obj.btnvehicalnewuser();
        obj.vehicleImported();
        obj.vehicleimportedvalue();
        obj.IsImportedWithSalvageCertificate();
        obj.colorID();
        obj.ValuationProformainvoice();
        obj.Vehiclevalue();
        obj.VehicleModified();
        obj.securedOvernightDiv();
        obj.vehicleSometimesUsedAsTrailer();
        obj.RoadworthyAndGoodCondition();
        obj.MileageInKm();
        obj.mileageDivId();
        obj.enginecapacity();
        obj.soleOwner();
        obj.usrdetail();
        obj.title();
        obj.gender();
        obj.Dateofbirth();
        obj.maritalstatus();
        obj.validprovisional();
        obj.issueDateOfProvisionalLicense();
        obj.country();
        obj.presentlyemployed();
        obj.workindustry();
        obj.mainoccupation();
        obj.credit();
        obj.education();
        obj.motorinsurancepolicy();
        obj.insurancecompany();
        obj.vehicles();
        obj.emailaddress();
        obj.travelwithbaby();
        obj.ages();
        obj.medically();
        obj.accidentclaim();
        obj.drivinghistory();
        obj.prosecuted();
        obj.applicationdeclined();
        obj.excessincreased();
        obj.cancelledorrenewal();
        obj.consecutiveperiod();
        obj.info();
        obj.specialdiscount();
        obj.NonCommissioned();
        obj.camerainstalled();
        obj.fulltimegovernmentemployee();
        obj.homeownerpolicy();
        obj.insurerwithpolicy();
        obj.yearshomeownerpolicy();
        obj.buyhomeownerpolicy();
        obj.Isthisvehiclecurrentlyinsured();
        obj.policytostart();
        obj.PolicyStartDate();
        obj.NCD();
        obj.NCDtovehicle();
        obj.anothermotorinsurancepolicy();
        obj.anyartisticpaint();
        obj.lowestpossiblequotes();

    }
}