package MIBL.Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.Console;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static java.io.Console.*;

public class GetQuickQuote_Page {
    WebDriver driver;

    //Xpath for all Controls
    By aboutus = By.xpath("//a[contains(text(),'About Us')]");
    By btnQuickQuote = By.xpath("//span[contains(text(),'Get a Quick Quote')]");
    By btnparish = By.xpath("//span[contains(text(),'Clarendon')]");
    By btnClarendon = By.xpath("//span[contains(text(),'Aenon Town')]");
    By btnselectvehicle = By.xpath("//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[2]");
    By btncontinue = By.id("btnContinue");
    By btnmanufactureyear = By.id("selectValue");
    By inputmanufacturedyear = By.xpath("//label[contains(text(),'2020')]");
    By btnvehiclemaker = By.id("selectYear");
    By inputvehiclemaker = By.xpath("//div[@id='vehicleMakeTypesDivId']//div[4]//div[1]//label[1]");
    By btnvehiclemodel = By.xpath("//div[@id='vehicleModelDivId']//button[@id='selectValue']//*");
    By inputvehiclemodel = By.xpath("//label[contains(text(),'Pulsar')]");
    By btnprimaryuse = By.xpath("//span[contains(text(),'Social and Domestic (including travelling to and f')]");
    By btndistancetravel = By.xpath("//div[@class='form-group vehicle-type-radio yellow-gray-radio dist-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    By btncurrentstatumotorcyclepayment = By.id("paymentStatus0");
    By btntypeofcover = By.xpath("//span[contains(text(),'Insured only')]");
    By btnComprehensive = By.xpath("//span[contains(text(),'Comprehensive')]");
    By btnmotorcycleownedcompny = By.xpath("//label[@id='vehicleCompanyOwned0']");
    By inputcompanyname = By.id("companyofName");
    By btnvehiclePurchased = By.xpath("//label[@id='vehiclePurchased0']");
    By btnvehicalnewuser = By.id("vehicleNewUsed0");
    By btnvehicleImported = By.id("vehicleImported0");
    By btnvehicleimportedvalue = By.xpath("//div[@class='form-group vehicle-type-radio yellow-gray-radio vehicle-import-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    By btnIsImportedWithSalvageCertificate = By.id("IsImportedWithSalvageCertificate0");
    By btncolorID = By.xpath("//div[@id='colourDivId']//div[2]//label[1]");
    By btnValuationProformainvoice = By.id("ValuationProformainvoice0");
    By btnvehicleValue = By.id("vehicleValue");
    By btnVehicleModified = By.id("IsVehicleModified0");
    By btnsecuredOvernightDiv = By.xpath("//div[@id='securedOvernightDivId']//div[3]//label[1]");
    By btnvehicleSometimesUsedAsTrailer = By.xpath("//div[@id='vehicleSometimesUsedAsTrailerDivId']//div[@class='group-step form-group vehicle-type-radio yellow-gray-radio cover-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    By btnRoadworthyAndGoodCondition = By.id("RoadworthyAndGoodCondition0");
    By btnisMileageInKm = By.id("isMileageInKmDivId");
    By btnmileageDivId = By.xpath("//input[@placeholder='insert numbers mileage/kilometers']");
    By btnenginecctype = By.id("ccHpTypeDivId");
    By dropEnginecc = By.xpath("//label[contains(text(),'125')]");
    By btnNextForm = By.id("btnNextForm");
    By btnsoleOwner = By.id("soleOwner0");
    By inputfirstname = By.xpath("//input[@placeholder='First Name']");
    By inputmiddlename = By.xpath("//input[@placeholder='Middle Name']");
    By inputlastname = By.xpath("//input[@placeholder='Last Name']");
    By btntitle = By.xpath("//div[@class='group-step form-group vehicle-type-radio yellow-gray-radio cover-radio d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    By Gender = By.id("inGender0");
    By Dateofbirth = By.id("clientDob");
    By maritalstatus = By.xpath("//div[@class='group-step section py-4 py-xl-5 fade show ng-scope']//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[1]//label[1]");
    By maritalstatus1 = By.xpath("//div[@class='group-step section py-4 py-xl-5 fade show ng-scope']//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[1]//label[1]//span[1]");
    //By maritalstatus = By.xpath("//div[@class='group-step section py-4 py-xl-5 fade show ng-scope']//div[@class='form-group vehicle-type-radio text-uppercase d-flex flex-wrap justify-content-center']//div[2]//label[1]");
    By btnvalidprovisional = By.xpath("//span[contains(text(),'Active')]");
    By drpissueDateOfProvisionalLicense = By.xpath("//input[@name='issueDateOfProvisionalLicense']");
    By country = By.xpath("//span[contains(text(),'CANADA')]");
    By presentlyemployed = By.xpath("//span[contains(text(),'Yes')]");
    By workindustry = By.xpath("//span[contains(text(),'Computer & Software')]");
    By mainoccupation = By.id("mainOccupationDivId");
    By btncredit = By.xpath("//span[@class='mib mib-Excellent']");
    By btneducation = By.xpath("//div[@id='educationDivId']//div[4]//label[1]");
    By btnmotorinsurancepolicy = By.id("isHaveMotorInsurancePolicyName0");
    By btninsurancecompany = By.xpath("//div[@class='row no-gutters border-left-dashed border-top-dashed']//div[1]//div[1]//label[1]");
    By btnvehicles = By.id("haveMoreThanTwoVehicles0");
    By inputemailaddress = By.xpath("//input[@placeholder='Insert email address']");
    By btntravelwithbaby = By.id("babyOnBoard0");
    By btnages = By.xpath("//div[@id='babyAgeDivId']//div[2]//label[1]");
    By btnmedically = By.xpath("//button[@id='selectValue']");
    By btnmedically1 = By.xpath("//span[contains(text(),'No to all')]");
    By btnaccidentclaim = By.id("accidentsorClaimsInsured1");
    By btndrivinghistory = By.id("receivedTicketInsured1");
    By btnprosecuted = By.id("motorOffenseInsured1");
    By btnapplicationdeclined = By.id("declinedInsured1");
    By btnexcessincreased = By.id("specialConditionInsured1");
    By btncancelledorrenewal = By.id("policyCancelledInsured1");
    By btnconsecutiveperiod = By.id("notDrivenInsured1");
    By btninfo = By.xpath("//span[contains(text(),'Yes! The information is correct')]");
    By btnspecialdiscount = By.xpath("//div[@id='SpecialDiscountDivId']//div[2]//label[1]");
    By btnNonCommissioned = By.id("noncommision0");
    By btncamerainstalled = By.id("camerainstalledonvehiclemain0");
    By btnfulltimegovernmentemployee = By.id("areYouGovernmentEmployee0");
    By btnhomeownerpolicy = By.id("homeOwnerPolicy0");
    By btninsurerwithpolicy = By.xpath("//div[@class='row no-gutters border-left-dashed border-top-dashed']//div[1]//div[1]//label[1]");
    By btnyearshomeownerpolicy = By.xpath("//div[@id='noOfYearsWithHomePolicyDivId']//div[2]//label[1]");
    By btnbuyhomeownerpolicy = By.id("broker1");
    By btnIsthisvehiclecurrentlyinsured = By.id("existingCover1");
    By btnpolicytostart = By.xpath("//div[@id='policyStartDivId']//div[2]//label[1]");
    By btnPolicyStartDate = By.id("PolicyStartDate");
    By btnNCD = By.xpath("//div[@id='noClaimDiscountDivId']//div[2]//label[1]");
    By btnNCDtovehicle=By.id("isApplyThisNCD1");
    By btnanothermotorinsurancepolicy = By.id("motorPolicy1");
    By btnanyartisticpaint = By.id("artisticPaintFinishes1");
    By btnlowestpossiblequotes = By.id("quoteListDivId");

    //Read data from properties file
    private java.util.Properties prop = null;

    public GetQuickQuote_Page(WebDriver driver) {
        this.driver = driver;
    }

    public void readPropertiesFile() {
        prop = new Properties();
        try {
            InputStream input = new
                    FileInputStream("D:\\Automation\\Automation_Practice\\Automation_Projects\\src\\MIBL\\utility\\Readdata.properties");
            prop.load(input);


        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String getPropertyValue(String key) {
        return prop.getProperty(key);
    }


    //button QuickQuote
    public void QuickQuote() {
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.findElement(btnQuickQuote).click();
    }

    //select parish
    public void parish() {
        driver.findElement(btnparish).click();
    }

    //select Calrendon
    public void Clarendon() {
        driver.findElement(btnClarendon).click();
    }

    //select vehicale
    public void selectvehicle() throws InterruptedException {
        /*
        /*WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.elementToBeSelected(btnselectvehicle));
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        /*WebElement wb = driver.findElement(btnselectvehicle);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("arguments[0].click();", wb);
        //WebDriverWait wait = new WebDriverWait(driver, 10)\
        //WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(btnselectvehicle));
        //element.click();

       /* WebElement myelement = driver.findElement(btnselectvehicle);
        JavascriptExecutor jse2 = (JavascriptExecutor)driver;
        jse2.executeScript("arguments[0].scrollIntoView()", myelement);
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       /* WebElement element = driver.findElement(btnselectvehicle);
        Actions actions = new Actions(driver);
        actions.click(element).build().perform();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(btnselectvehicle));
        element.click();
        */
        Thread.sleep(3000);
        WebElement object1 = driver.findElement(btnselectvehicle);
        if (object1.isEnabled()) {
            object1.click();
        }
    }

    //press on continue
    public void continuebtn() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(btncontinue));
        element.click();

    }

    //Select year of manufacture
    public void manufactureyear() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(btnmanufactureyear).click();
        WebElement element = driver.findElement(inputmanufacturedyear);
        Actions actions = new Actions(driver);
        actions.click(element).click().build().perform();
    }

    //select vehicle maker
    public void vehiclemaker() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(btnvehiclemaker).click();
        Thread.sleep(3000);
        WebElement element = driver.findElement(inputvehiclemaker);
        Actions actions = new Actions(driver);
        actions.click(element).click().build().perform();
        Thread.sleep(3000);
    }

    //select vehicle model

    public void vehiclemodel() throws InterruptedException {
        /*driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(btnvehiclemodel).click();*/
        //Thread.sleep(3000);
      /*  WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.elementToBeSelected(btnvehiclemodel));*/
        driver.findElement(btnvehiclemodel).click();
        /*WebElement element = driver.findElement(btnvehiclemodel);
        Actions actions = new Actions(driver);
        actions.click(element).click().build().perform();*/
        driver.findElement(inputvehiclemodel).click();
        Thread.sleep(3000);

    }

    //select primary button
    public void btnprimaryuse() {
        driver.findElement(btnprimaryuse).click();

    }

    //select distancetravel
    public void btndistancetravel() throws InterruptedException {
        driver.findElement(btndistancetravel).click();
        Thread.sleep(3000);
    }

    //
    public void currentstatumotorcyclepayment() {
        driver.findElement(btncurrentstatumotorcyclepayment).click();
    }


    public void typeofcover() {
        driver.findElement(btntypeofcover).click();
    }

    public void comprehensive() {
        driver.findElement(btnComprehensive).click();
    }

    public void motorcycleownedcompny() {
        driver.findElement(btnmotorcycleownedcompny).click();
    }

    public void companyname() {
        driver.findElement(inputcompanyname).sendKeys(prop.getProperty("companyname"));
    }

    public void vehiclePurchased() {
        driver.findElement(btnvehiclePurchased).click();
    }

    public void btnvehicalnewuser() {
        driver.findElement(btnvehicalnewuser).click();
    }

    public void vehicleImported() throws InterruptedException {
        driver.findElement(btnvehicleImported).click();
        Thread.sleep(3000);
    }

    public void vehicleimportedvalue() {
        driver.findElement(btnvehicleimportedvalue).click();
    }

    public void IsImportedWithSalvageCertificate() {
        driver.findElement(btnIsImportedWithSalvageCertificate).click();
    }

    public void colorID() {
        driver.findElement(btncolorID).click();
    }

    public void ValuationProformainvoice() {
        driver.findElement(btnValuationProformainvoice).click();
    }

    public void Vehiclevalue() {
        driver.findElement(btnvehicleValue).sendKeys(prop.getProperty("Vehiclevalue"));
    }

    public void VehicleModified() {
        driver.findElement(btnVehicleModified).click();
    }

    public void securedOvernightDiv() {
        driver.findElement(btnsecuredOvernightDiv).click();
    }

    public void vehicleSometimesUsedAsTrailer() {
        driver.findElement(btnvehicleSometimesUsedAsTrailer).click();
    }

    public void RoadworthyAndGoodCondition() {
        driver.findElement(btnRoadworthyAndGoodCondition).click();
    }

    public void MileageInKm() {
        driver.findElement(btnisMileageInKm).click();
    }

    public void mileageDivId() {

        driver.findElement(btnmileageDivId).sendKeys(prop.getProperty("mileage"));
    }

    public void enginecapacity() throws InterruptedException {
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(btnenginecctype).click();
        WebDriverWait wait2 = new WebDriverWait(driver, 10);
        wait2.until(ExpectedConditions.elementToBeClickable(dropEnginecc)).click();
       /* WebElement element = driver.findElement(dropEnginecc);
        element.click();*/
       /* Actions actions = new Actions(driver);
        actions.click(element).click().build().perform();*/
        //Thread.sleep(2000);
        driver.findElement(btnNextForm).click();
        //Thread.sleep(2000);
    }

    public void soleOwner() throws InterruptedException {
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        /*WebDriverWait wait2 = new WebDriverWait(driver, 10);
        wait2.until(ExpectedConditions.elementToBeClickable(btnsoleOwner)).click();*/
        Thread.sleep(5000);
        WebElement element = driver.findElement(btnsoleOwner);
        Actions actions = new Actions(driver);
        actions.click(element).build().perform();
    }

    public void usrdetail() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(inputfirstname).sendKeys(prop.getProperty("Firstname"));
        driver.findElement(inputmiddlename).sendKeys(prop.getProperty("Middlename"));
        driver.findElement(inputlastname).sendKeys(prop.getProperty("Lastname"));
    }

    public void title() {
        driver.findElement(btntitle).click();
    }

    public void gender() {
        driver.findElement(Gender).click();
    }

    public void Dateofbirth() {
        driver.findElement(Dateofbirth).sendKeys(prop.getProperty("Dateofbirth"));

    }

    public void maritalstatus() throws InterruptedException {
        //driver.findElement(maritalstatus).click();
        Thread.sleep(3000);
        driver.findElement(maritalstatus).click();
        WebElement element = driver.findElement(maritalstatus1);
        Actions actions = new Actions(driver);
        actions.click(element).click().build().perform();
    }

    public void validprovisional() {

       /* WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(btnvalidprovisional));
        element.click();*/
        driver.findElement(btnvalidprovisional).click();
    }

    public void issueDateOfProvisionalLicense() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(drpissueDateOfProvisionalLicense).sendKeys(prop.getProperty("yearprovisional"));
        driver.findElement(btnNextForm).click();
    }

    public void country() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(country).click();
    }

    public void presentlyemployed() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(presentlyemployed).click();
    }

    public void workindustry() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(workindustry).click();
    }

    public void mainoccupation() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(mainoccupation).click();
    }

    public void credit() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btncredit).click();
    }

    public void education() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btneducation).click();
    }

    public void motorinsurancepolicy() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnmotorinsurancepolicy).click();
    }

    public void insurancecompany() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btninsurancecompany).click();
    }

    public void vehicles() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnvehicles).click();
    }

    public void emailaddress() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(inputemailaddress).sendKeys(prop.getProperty("emailaddress"));
        //driver.findElement(btnNextForm).click();
    }

    public void travelwithbaby() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btntravelwithbaby).click();
    }

    public void ages() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnages).click();
    }

    public void medically() throws InterruptedException {
        //driver.findElement(maritalstatus).click();
        Thread.sleep(3000);
        driver.findElement(btnmedically).click();
        WebElement element = driver.findElement(btnmedically1);
        Actions actions = new Actions(driver);
        actions.click(element).click().build().perform();
        driver.findElement(btnNextForm).click();
    }

    public void accidentclaim() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnaccidentclaim).click();
    }

    public void drivinghistory() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btndrivinghistory).click();
    }

    public void prosecuted() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnprosecuted).click();
    }

    public void applicationdeclined() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnapplicationdeclined).click();
    }

    public void excessincreased() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnexcessincreased).click();
    }

    public void cancelledorrenewal() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btncancelledorrenewal).click();
    }

    public void consecutiveperiod() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnconsecutiveperiod).click();
    }

    public void info() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btninfo).click();
        driver.findElement(btnNextForm).click();
    }

    public void specialdiscount() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnspecialdiscount).click();

    }

    public void NonCommissioned() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnNonCommissioned).click();

    }

    public void camerainstalled() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btncamerainstalled).click();

    }

    public void fulltimegovernmentemployee() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnfulltimegovernmentemployee).click();

    }

    public void homeownerpolicy() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnhomeownerpolicy).click();

    }

    public void insurerwithpolicy() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btninsurerwithpolicy).click();

    }

    public void yearshomeownerpolicy() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnyearshomeownerpolicy).click();

    }

    public void buyhomeownerpolicy() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnbuyhomeownerpolicy).click();

    }

    public void Isthisvehiclecurrentlyinsured() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnIsthisvehiclecurrentlyinsured).click();

    }

    public void policytostart() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnpolicytostart).click();

    }

    public void PolicyStartDate() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnPolicyStartDate).sendKeys(prop.getProperty("PolicyStartDate"));

    }

    public void NCD() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnNCD).click();

    }
    public void NCDtovehicle() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnNCDtovehicle).click();

    }

    public void anothermotorinsurancepolicy() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnanothermotorinsurancepolicy).click();

    }

    public void anyartisticpaint() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(btnanyartisticpaint).click();
        driver.findElement(btnNextForm).click();
    }

    public void lowestpossiblequotes() throws InterruptedException {
        Thread.sleep(2000);
        driver.findElement(By.name("YOUR LOWEST QUOTE")).click();
    }
}