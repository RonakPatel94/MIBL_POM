package Common_Methods;

import Base_Page.BasePage;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class ReadPropertiesFileData extends BasePage {
    //public WebDriver driver;
    private Properties prop = null;
    public ReadPropertiesFileData() {
        super();

        //this.driver = driver;
    }
    public void readPropertiesFile() {
        prop = new Properties();
        try {
            InputStream input = new
                    FileInputStream("D:\\Automation_Projects_Code\\Final_MIBL\\src\\main\\resources\\MIBLReaddata.properties");
            prop.load(input);

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String getPropertyValue(String key) {
        return prop.getProperty(key);
    }


   /* public void ReadPropertiesFileData1(String val) {

        File file = new File("D:\\Automation Projects Code\\MIBL_Maven_POM\\src\\main\\resources\\MIBLReaddata.properties");
        FileInputStream fileInput = null;
        System.out.println(file);
        try {
            fileInput = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Properties prop = new Properties();
        try {
            prop.load(fileInput);
            prop.getProperty(val);
        } catch (IOException e) {
            e.printStackTrace();
        }

       *//* Enumeration KeyValues = prop.keys();
        while (KeyValues.hasMoreElements()) {
            String key = (String) KeyValues.nextElement();
            String value = prop.getProperty(key);
            System.out.println(key + ":- " + value);*//*
        }
   *//* public String getPropertyValue(String key) {
        return prop.getProperty(key);
    }*/
}


