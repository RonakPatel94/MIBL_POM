package Base_Page;

import Common_Methods.CommonMethods;
import org.openqa.selenium.WebDriver;

public class BasePage {
    public WebDriver driver;
    public CommonMethods commonMethods;

    public BasePage() {
        this.driver = driver;

        commonMethods = new CommonMethods(driver);
    }
}
