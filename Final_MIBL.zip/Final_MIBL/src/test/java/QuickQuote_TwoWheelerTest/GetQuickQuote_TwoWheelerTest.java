package QuickQuote_TwoWheelerTest;

import Common_Methods.CommonMethods;
import Common_Methods.ExtentReports;
import Common_Methods.ReadPropertiesFileData;
import QuickQuote_TwoWheelerPage.GetQuickQuote_TwoWheelerPage;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GetQuickQuote_TwoWheelerTest extends ExtentReports {
    private int flag = 1;
    public java.util.Properties prop = null;
    ReadPropertiesFileData readPropertiesFileData = new ReadPropertiesFileData();

    public GetQuickQuote_TwoWheelerTest() {
        readPropertiesFileData.readPropertiesFile();
    }

    public GetQuickQuote_TwoWheelerTest(WebDriver passDriver, int Flag) {
        driver = passDriver;
        flag = Flag;
    }

    @Test(priority = 0)
    public void QuickQuoteTwoWheeler() throws InterruptedException {
        if (flag > 0) {
            test = extent.createTest("Quick QuoteWheeler Module");
            test.assignCategory("QuickQuote TwoWheeler Module");
        }

        CommonMethods commonMethods = new CommonMethods(driver);
        //ReadPropertiesFileData ReadPropertiesFileData = new ReadPropertiesFileData();
        GetQuickQuote_TwoWheelerPage GetQuickQuote_TwoWheelerPage = new GetQuickQuote_TwoWheelerPage();

        test.log(Status.INFO, "MIBL TestCase Started");

        //Step 1: Click on QuickQuote
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnQuickQuote), "Unable to Click on QuickQuote Button");
        test.log(Status.PASS, "Click on QuickQuote");

        //Step 2: Click on btnparish
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnparish), "Unable to Click on btnparish");
        test.log(Status.PASS, "Click on btnparish");

        //Step 3: Click on Kingstonlive  rop.getProperty("companyname")
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.Kingstonlive0), "Unable to Click on Kingstonlive");
        test.log(Status.PASS, "Click on Kingstonlive");

        System.out.println(readPropertiesFileData.getPropertyValue("companyname"));

        //prop.getProperty("companyname")
        //Step 4: Click on selectvehicle
        Thread.sleep(3000);
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnselectvehicle), "Unable to Click on selectvehicle");
        test.log(Status.PASS, "Click on selectvehicle");

        //Step 5: Click on Continue
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncontinue), "Unable to Click on continue");
        test.log(Status.PASS, "Click on continue");

        //Step 6: Click on manufactureyear
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmanufactureyear), "Unable to Click on manufactureyear");
        test.log(Status.PASS, "Click on manufactureyear");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.inputmanufacturedyear), "Unable to insert input manufactured year");
        test.log(Status.PASS, "Click on input manufactured year");

        //Step 7: select vehicle maker
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehiclemaker), "Unable to Click on vehiclemaker");
        test.log(Status.PASS, "Click on vehicle maker");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.inputvehiclemaker), "Unable to insert input vehicle maker");
        test.log(Status.PASS, "Click on vehicle maker");

        //Step 8: select vehicle model
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehiclemodel), "Unable to Click on vehicle model");
        test.log(Status.PASS, "Click on vehicle model");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.inputvehiclemodel), "Unable to insert input vehicle model");
        test.log(Status.PASS, "insert vehicle model");

        //Step 9: select primary use
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnprimaryuse), "Unable to Click on primary use");
        test.log(Status.PASS, "Click on primary use");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btndistancetravel), "Unable to Click on primary use");
        test.log(Status.PASS, "Click on distancetravel");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncurrentstatumotorcyclepayment), "Unable to click current status motorcycle payment");
        test.log(Status.PASS, "Click on current status motorcycle payment");

        //Step 10: typeofcover
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btntypeofcover), "Unable to Click on typeofcover");
        test.log(Status.PASS, "Click on typeofcover");

        //Step 11: comprehensive
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnComprehensive), "Unable to Click on comprehensive");
        test.log(Status.PASS, "Click on comprehensive");

        //Step 12: motorcycleownedcompny
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmotorcycleownedcompny), "Unable to Click on motorcycle owned company");
        test.log(Status.PASS, "Click on motorcycle owned company");

        //Step 13: motorcycle owned company
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmotorcycleownedcompny), "Unable to Click on motorcycle owned company");
        test.log(Status.PASS, "Click on motorcycle owned company");

        //Step 14:Company name
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputcompanyname, readPropertiesFileData.getPropertyValue("companyname")), "Unable to Insert companyname");
        test.log(Status.PASS, "Click on companyname");

        //Step 15: vehiclePurchased
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehiclePurchased), "Unable to Click on vehiclePurchased");
        test.log(Status.PASS, "Click on vehiclePurchased");

        //Step 16: vehicalnewuser
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehicalnewuser), "Unable to Click on vehical newuser");
        test.log(Status.PASS, "Click on vehical newuser");

        //Step 17: vehicleImported
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehicleImported), "Unable to Click on vehicle Imported");
        test.log(Status.PASS, "Click on vehicle Imported");

        //Step 18: vehicleimportedvalue
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehicleimportedvalue), "Unable to Click on vehicle imported value");
        test.log(Status.PASS, "Click on vehicle imported value");

        //Step 19: ImportedWithSalvageCertificate
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnIsImportedWithSalvageCertificate), "Unable to Click on Imported With SalvageCertificate");
        test.log(Status.PASS, "Click on Imported With SalvageCertificate");

        //Step 20: btncolorID
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncolorID), "Unable to Click on btncolorID");
        test.log(Status.PASS, "Click on btncolorID");

        //Step 21: ValuationProformainvoice
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnValuationProformainvoice), "Unable to Click on Valuation Performance invoice");
        test.log(Status.PASS, "Click on Valuation Performance invoice");

        //Step 22: Vehiclevalue
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.btnvehicleValue, readPropertiesFileData.getPropertyValue("Vehiclevalue")), "Unable to Insert Vehiclevalue");
        test.log(Status.PASS, "Click on Vehiclevalue");

        //Step 23: VehicleModified
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnVehicleModified), "Unable to Click on VehicleModified");
        test.log(Status.PASS, "Click on VehicleModified");

        //Step 24: securedOvernightDiv
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnsecuredOvernightDiv), "Unable to Click on SecuredOvernightDiv");
        test.log(Status.PASS, "Click on SecuredOvernightDiv");

        //Step 25: vehicleSometimesUsedAsTrailer
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehicleSometimesUsedAsTrailer), "Unable to Click on Vehicle Sometimes Used AsTrailer");
        test.log(Status.PASS, "Click on Vehicle Sometimes Used AsTrailer");

        //Step 26: RoadworthyAndGoodCondition
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnRoadworthyAndGoodCondition), "Unable to Click on Road worthy And GoodCondition");
        test.log(Status.PASS, "Click on Road worthy And GoodCondition");

        //Step 27: btnisMileageInKm
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnisMileageInKm), "Unable to Click on Mileage In Km");
        test.log(Status.PASS, "Click on Mileage In Km");

        //Step 28: btnmileageDivId
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.btnmileageDivId, readPropertiesFileData.getPropertyValue("mileage")), "Unable to Insert btnmileageDivId");
        test.log(Status.PASS, "Click on mileageDivId");

        //Step 29: enginecapacity
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnenginecctype), "Unable to Click on Engine cc-type");
        test.log(Status.PASS, "Click on Engine cc-type");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.dropEnginecc), "Unable to Click on Dropdown Engine cc-type");
        test.log(Status.PASS, "Click on Dropdown Engine cc-type");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on NextButton");
        test.log(Status.PASS, "Click on NextButton");

        //Step 30: soleOwner
        Assert.assertTrue(commonMethods.clickByJS(GetQuickQuote_TwoWheelerPage.btnsoleOwner), "Unable to Click on soleOwner");
        test.log(Status.PASS, "Click on SoleOwner and User details");

        /*Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputfirstname, readPropertiesFileData.getPropertyValue("Firstname")), "Unable to Insert Firstname");
        test.log(Status.PASS, "Click on Firstname");*/
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputfirstname, readPropertiesFileData.getPropertyValue("Firstname")+ commonMethods.getRandomString()), "Unable to Insert Firstname");
        test.log(Status.PASS, "Click on Firstname");
        //System.out.println(readPropertiesFileData.getPropertyValue("Firstname")+ commonMethods.getRandomString());

       /*Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputmiddlename, readPropertiesFileData.getPropertyValue("Middlename")), "Unable to Insert Middlename");
        test.log(Status.PASS, "Click on Middlename");*/
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputmiddlename, readPropertiesFileData.getPropertyValue("Middlename")+CommonMethods.getRandomString()), "Unable to Insert Middlename");
        test.log(Status.PASS, "Click on Middlename");
        //System.out.println(readPropertiesFileData.getPropertyValue("Middlename")+ commonMethods.getRandomString());


        /*Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputlastname, readPropertiesFileData.getPropertyValue("Lastname")), "Unable to Insert Lastname");
        test.log(Status.PASS, "Click on Lastname");*/
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputlastname, readPropertiesFileData.getPropertyValue("Lastname")+CommonMethods.getRandomString()), "Unable to Insert Lastname");
        test.log(Status.PASS, "Click on Lastname");
        //System.out.println(readPropertiesFileData.getPropertyValue("Lastname")+ commonMethods.getRandomString());

        //Step 31: title
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btntitle), "Unable to Click on title");
        test.log(Status.PASS, "Click on title");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.Gender), "Unable to Click on Gender");
        test.log(Status.PASS, "Click on Gender");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.Dateofbirth, readPropertiesFileData.getPropertyValue("Dateofbirth")), "Unable to Insert Date of birth");
        test.log(Status.PASS, "Click on Date of birth");

        //Step 32 : maritalstatus
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.maritalstatus), "Unable to Click on marital status");
        test.log(Status.PASS, "Click on marital status");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.maritalstatus1), "Unable to Click on marital status");
        test.log(Status.PASS, "Click on marital status 1");

        //Step 33:validprovisional
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvalidprovisional), "Unable to Click on valid provisional");
        test.log(Status.PASS, "Click on valid provisional");

        //Step 34 :issueDateOfProvisionalLicense
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.drpissueDateOfProvisionalLicense, readPropertiesFileData.getPropertyValue("yearprovisional")), "Unable to Insert Year of provisional");
        test.log(Status.PASS, "Click on Year of provisional");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on Next Button");
        test.log(Status.PASS, "Click on Next Button");

        //Step 35:country
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.country), "Unable to Click on country");
        test.log(Status.PASS, "Click on country");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.presentlyemployed), "Unable to Click on presentlyemployed");
        test.log(Status.PASS, "Click on Presently employed");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.workindustry), "Unable to Click on work industry");
        test.log(Status.PASS, "Click on work industry");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.mainoccupation), "Unable to Click on main occupation");
        test.log(Status.PASS, "Click on main occupation");

       //Step 36:credit
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncredit), "Unable to Click on credit");
        test.log(Status.PASS, "Click on Credit");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btneducation), "Unable to Click on Education");
        test.log(Status.PASS, "Click on Education");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmotorinsurancepolicy), "Unable to Click on Motor Insurance policy");
        test.log(Status.PASS, "Click on Motor Insurance policy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btninsurancecompany), "Unable to Click on button Motor Insurance policy");
        test.log(Status.PASS, "Click on Motor Insurance policy Button");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnvehicles), "Unable to Click on Vehicles");
        test.log(Status.PASS, "Click on Vehicles");

       //Step 37:User Details
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputemailaddress, readPropertiesFileData.getPropertyValue("emailaddress")), "Unable to Insert Email Address");
        test.log(Status.PASS, "Click on Email Address");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btntravelwithbaby), "Unable to Click on Travel with baby");
        test.log(Status.PASS, "Click on Travel with baby");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnages), "Unable to Click on Age");
        test.log(Status.PASS, "Click on Age");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmedically), "Unable to Click on Medically");
        test.log(Status.PASS, "Click on Medically");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmedically1), "Unable to Click on Medically Button");
        test.log(Status.PASS, "Click on Medically Button");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on NextForm");
        test.log(Status.PASS, "Click on NextForm");

        //Step 38:Car Details
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnaccidentclaim), "Unable to Click on Accident Claim");
        test.log(Status.PASS, "Click on Accident claim");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btndrivinghistory), "Unable to Click on driving history");
        test.log(Status.PASS, "Click on Driving history");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnprosecuted), "Unable to Click on Prosecuted");
        test.log(Status.PASS, "Click on Prosecuted");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnapplicationdeclined), "Unable to Click on Application declined");
        test.log(Status.PASS, "Click on Application declined");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnexcessincreased), "Unable to Click on Excess increased");
        test.log(Status.PASS, "Click on Excess increased");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncancelledorrenewal), "Unable to Click on Cancelled or renewal");
        test.log(Status.PASS, "Click on Cancelled or renewal");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnconsecutiveperiod), "Unable to Click on Consecutive Period");
        test.log(Status.PASS, "Click on Consecutive Period");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btninfo), "Unable to Click on Info Button");
        test.log(Status.PASS, "Click on Info Button");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on NextForm");
        test.log(Status.PASS, "Click on NextForm");

        //Step 39:specialdiscount
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnspecialdiscount), "Unable to Click on specialdiscount");
        test.log(Status.PASS, "Click on specialdiscount");

        //Step 40:NonCommissioned
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNonCommissioned), "Unable to Click on NonCommissioned");
        test.log(Status.PASS, "Click on NonCommissioned");

        //Step 41:Camera installed
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncamerainstalled), "Unable to Click on Camera installed");
        test.log(Status.PASS, "Click on Camera installed");

        //Step 42:fulltime government employee
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnfulltimegovernmentemployee), "Unable to Click on Fulltime government employee");
        test.log(Status.PASS, "Click on fulltime government employee");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnhomeownerpolicy), "Unable to Click on home owner policy");
        test.log(Status.PASS, "Click on Home owner Policy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btninsurerwithpolicy), "Unable to Click on Insurer with policy");
        test.log(Status.PASS, "Click on Insurer with policy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnyearshomeownerpolicy), "Unable to Click on Years home owner policy");
        test.log(Status.PASS, "Click on Years home owner policy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnbuyhomeownerpolicy), "Unable to Click on Buy home owner policy");
        test.log(Status.PASS, "Click on Buy Home Owner Policy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnIsthisvehiclecurrentlyinsured), "Unable to Click on Is this vehicle currently insured");
        test.log(Status.PASS, "Click on Is this vehicle currently insured");

        //Step 43:Policy to start
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnpolicytostart), "Unable to Click on Policy to start");
        test.log(Status.PASS, "Click on Policy to start");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.btnPolicyStartDate, readPropertiesFileData.getPropertyValue("PolicyStartDate")), "Unable to Insert PolicyStartDate");
        test.log(Status.PASS, "Click on Policy Start Date");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNCD), "Unable to Click on NCD");
        test.log(Status.PASS, "Click on NCD");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNCDtovehicle), "Unable to Click on NCD to vehicle");
        test.log(Status.PASS, "Click on NCD to vehicle");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnanothermotorinsurancepolicy), "Unable to Click on Another Motor Insurance Policy");
        test.log(Status.PASS, "Click on Another Motor Insurance Policy");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnanyartisticpaint), "Unable to Click on Any Artistic Paint");
        test.log(Status.PASS, "Click on Any Artistic Paint");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on NextForm");
        test.log(Status.PASS, "Click on NextForm");
        //Step 44 : lowestpossiblequotes
        List<WebElement> clomVal = driver.findElements(GetQuickQuote_TwoWheelerPage.txtcarrier);
        for (int i = 0; i < clomVal.size(); i++) {
            //test.log(Status.PASS,"The Value is :\n" + clomVal.get(i).getText());
            //System.out.println("the Value is :\n " + clomVal.get(i).getText());
            if (clomVal.get(i).equals("YOUR LOWEST QUOTE\n")) {
                clomVal.get(i).click();
            }
            break;
        }
        //Step 45:showquote
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnshowquote), "Unable to Click on Show Quote");
        test.log(Status.PASS, "Click on Show Quote");

       //Step 46:Quotecompare
        List<WebElement> myList = driver.findElements(By.xpath("//div[@class='comp-comparision-table d-none d-lg-block']//tr[3]//td//span"));
        //To store all web elements into list
        List<String> all_elements_text = new ArrayList<String>();
        for (int i = 0; i < myList.size(); i++) {
            all_elements_text.add(myList.get(i).getText());
            System.out.println(myList.get(i).getText());
        }
        Object objmin = Collections.min(all_elements_text);
        Object objmax = Collections.max(all_elements_text);
        test.log(Status.PASS, "The Lowest value :" + objmin);
        test.log(Status.PASS, "The Highest value :" + objmax);
        //System.out.println("The Lowest value :" + objmin);
        //System.out.println("The Highest value :" + objmax);
        if (objmin == objmax) {
            System.out.println("Same lowest value found");
        } else {
            Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.lowestbuyvalue), "Unable to Click on Lowest Buy Value");
            test.log(Status.PASS, "Click on Lowest Buy Value");
        }

        //Step 47: Close Associate Holding
        Thread.sleep(3000);
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputTRN, readPropertiesFileData.getPropertyValue("TRN")), "Unable to Insert TRN");
        test.log(Status.PASS, "Click on TRN");
        Assert.assertTrue(commonMethods.clickByJS(GetQuickQuote_TwoWheelerPage.btncloseassociateholding), "Unable to Click on Close Associate Holding");
        test.log(Status.PASS, "Click on Close Associate Holding");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.btnmothermaidenname, readPropertiesFileData.getPropertyValue("Mothername")), "Unable to Insert Mother Name");
        test.log(Status.PASS, "Click on Mother Name");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputaddress, readPropertiesFileData.getPropertyValue("address")), "Unable to Insert address");
        test.log(Status.PASS, "Click on Address");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputstreetnumber, readPropertiesFileData.getPropertyValue("Streetnumber")), "Unable to Insert Street Number");
        test.log(Status.PASS, "Click on Street Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputstreetname, readPropertiesFileData.getPropertyValue("Streetname")), "Unable to Insert Street Name");
        test.log(Status.PASS, "Click on Street Name");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnIsyourmailingaddress), "Unable to Click on Is Your Mailing Address");
        test.log(Status.PASS, "Click on Your Mailing Address");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputcompanyname1, readPropertiesFileData.getPropertyValue("companyname1")), "Unable to Insert companyname1");
        test.log(Status.PASS, "Click on companyname1");
       /* Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnparish), "Unable to Click on btnparish");
        test.log(Status.PASS, "Click on btnparish");*/
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.Kingstonlive1), "Unable to Click on Kingstonlive");
        test.log(Status.PASS, "Click on Kingstonlive");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputmobile, readPropertiesFileData.getPropertyValue("mobilenumber")), "Unable to Insert mobilenumber");
        test.log(Status.PASS, "Click on Mobile Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputwork, readPropertiesFileData.getPropertyValue("Worknumber")), "Unable to Insert Worknumber");
        test.log(Status.PASS, "Click on Worknumber");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputResidential, readPropertiesFileData.getPropertyValue("Residentialnumber")), "Unable to Insert Residential Number");
        test.log(Status.PASS, "Click on Residential Number");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputmotorcycleenginenumber, readPropertiesFileData.getPropertyValue("motorcycleenginenumber")), "Unable to Insert motorcycle engine number");
        test.log(Status.PASS, "Click on motorcycle engine number");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputmotorcycleChassisnumber, readPropertiesFileData.getPropertyValue("motorcycleChassisnumber")), "Unable to Insert Motorcycle Chassis number");
        test.log(Status.PASS, "Click on Motorcycle Chassis Number");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on NextForm");
        test.log(Status.PASS, "Click on NextForm");

        //Step 48: Pay Your Premiums
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnsalary), "Unable to Click on Salary");
        test.log(Status.PASS, "Click on Salary");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnfullpayment), "Unable to Click on Full Payment");
        test.log(Status.PASS, "Click on Full Payment");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btncreditcard), "Unable to Click on Credit Card");
        test.log(Status.PASS, "Click on Credit Card");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnmastercard), "Unable to Click on mastercard");
        test.log(Status.PASS, "Click on Mastercard");

        //Step 48:Creditcardinformation
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputcardname, readPropertiesFileData.getPropertyValue("cardname")), "Unable to Insert cardname");
        test.log(Status.PASS, "Click on Card Name");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputcardnumber, readPropertiesFileData.getPropertyValue("cardnumber")), "Unable to Insert cardnumber");
        test.log(Status.PASS, "Click on CardNumber");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btndropclickmonth), "Unable to Click on DropDown Month");
        //test.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.drpcardmonth), "Unable to Click on cardmonth");
        test.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btndropclick), "Unable to Click on Month");
        test.log(Status.PASS, "Click on Month");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.drpcardyear), "Unable to Click on Year");
        test.log(Status.PASS, "Click on Year");
        Assert.assertTrue(commonMethods.enterTextInInputField(GetQuickQuote_TwoWheelerPage.inputsecuritycode, readPropertiesFileData.getPropertyValue("securitycode")), "Unable to Insert cardnumber");
        test.log(Status.PASS, "Click on Security Code");
        Assert.assertTrue(commonMethods.clickOnLinkOrButton(GetQuickQuote_TwoWheelerPage.btnNextForm), "Unable to Click on NextForm");
        test.log(Status.PASS, "Click on NextForm");
       // Thread.sleep(10000);
        Assert.assertTrue(commonMethods.verifyElementIsVisible(GetQuickQuote_TwoWheelerPage.thankyou), "Unable to Click your payment was successful!");
        test.log(Status.PASS, "Your Payment Was Successful!");
    }
}
